Steps to run the code for question 1:
Step-1: Save the Python file with name ques1.py
Step-2: Open the integrated terminal in Visual Studio Code. Navigate to the directory where your Python script is located using the cd command
Step-3: Copy the path to data set in the input_file variable in the main function (replace 'Data/Isabel_2D.vti' with the actual file name)
Step-4: Run your Python script in the terminal by typing the command: python ques1.py
Step-5: Enter the desired isovalue
Step-6: Rotate and view the rendered image for isocontour(in green color)
Step-7: File named output_file_1.vtp will be generated and can be opened in Paraview


Steps to run the code for question 2:

Step-1: Save the Python file with name ques2.py
Step-2: Open the integrated terminal in Visual Studio Code. Navigate to the directory where your Python script is located using the cd command
Step-3: Copy the path to data set in the input variable in the main function (replace 'Data/Isabel_3D.vti' with the actual file name)
Step-4: Run your Python script in the terminal by typing the command: python ques2.py
Step-5: Select the option to use Phong Shading by typing 'yes' or 'no'
Step-6: Rotate and view the rendered image for front and back views